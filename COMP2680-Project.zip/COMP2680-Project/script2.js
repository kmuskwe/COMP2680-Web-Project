function updatePrivateComment(name) 
{
  var privateCommentElement = document.getElementById("privateComment" + name);
  if (privateCommentElement) 
  {
    var originalText = privateCommentElement.value.trim();
    var maskedText = "#".repeat(originalText.length);
    privateCommentElement.value = maskedText;
  }
}
function submitForm() 
{
  alert("Form Submitted!!!");
  resetForm();
}
function resetForm() 
{
  var rows = document.querySelectorAll("tbody tr");
  rows.forEach(function (row) 
  {
    var ratingElement = row.querySelector("select");
    if (ratingElement) 
	{
      ratingElement.value = "1";
    }
    var commentElement = row.querySelector("textarea[id^='comment']");
    if (commentElement) 
	{
      commentElement.value = "";
    }
    var privateCommentElement = row.querySelector("textarea[id^='privateComment']");
    if (privateCommentElement) 
	{
      privateCommentElement.value = "";
    }
  });
}