// This fulfills requirement 5.6 (b)
function submitPledge(amountInputId, progressBarId, totalAmountId) 
{
  const amountInput = document.getElementById(amountInputId);
  const progressBar = document.getElementById(progressBarId);
  const totalAmount = document.getElementById(totalAmountId);
  const pledgeAmount = parseFloat(amountInput.value);

  if (isNaN(pledgeAmount) || pledgeAmount < 0) 
  {
	// This fulfills requirement 5.6 (c)
    alert('Enter a valid positive number.');
	// This fulfills requirement 5.3 (c) 
	amountInput.focus();
    return;
  }
  const currentWidth = parseFloat(progressBar.style.width) || 0;
  const newWidth = Math.min(currentWidth + pledgeAmount, 100); 
  const totalValue = parseFloat(totalAmount.textContent.replace('$', '')) || 0;
  const newTotalValue = totalValue + pledgeAmount;
  progressBar.style.width = `${newWidth}%`;
  progressBar.style.backgroundColor = '#4CAF50'; 
  totalAmount.textContent = `$${newTotalValue.toFixed(2)}`;
  amountInput.value = '';
}
