// This fulfills requirement 5.6 (a)
var maintenanceMessages = [];
var maintenanceRequestsMessages = [];

function sendMessage(inputId, messagesArray, listId) 
{
  var messageInput = document.getElementById(inputId);
  var messageText = messageInput.value.trim();
  if (messageText !== '') 4
  {
    messagesArray.push({ text: messageText, comments: [] });
    messageInput.value = '';
    updateMessageList(listId, messagesArray);
  }
}

function updateMessageList(listId, messagesArray) 
{
  var messageList = document.getElementById(listId);
  messageList.innerHTML = '';
  for (var i = 0; i < messagesArray.length; i++) 
  {
    var messageItem = document.createElement('li');
    messageItem.className = 'message';
    var messageNumber = i + 1;
    var messageNumberText = messageNumber + '. ';
    var messageText = messagesArray[i].text;
    messageItem.textContent = messageText;
    var space = document.createTextNode(' ');
    messageItem.appendChild(space);
    if (messagesArray[i].comments.length > 0) 
	{
      var commentsText = messagesArray[i].comments.map(function (comment, index) 
	  {
        var commentNumber = index + 1;
        return '(COMMENT ' + commentNumber + ': ' + comment + ')';
      }).join(' ');
      var commentsNode = document.createTextNode(commentsText);
      messageItem.appendChild(commentsNode);
    }
    var commentButton = document.createElement('button');
    commentButton.textContent = 'Comment';
    commentButton.onclick = function () 
	{
      commentOnPost(this.parentNode, listId);
    };
    messageItem.appendChild(commentButton);
    var removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.onclick = function () 
	{
      removePost(this.parentNode, listId);
    };
    messageItem.appendChild(removeButton);
    messageList.appendChild(messageItem);
  }
}

function commentOnPost(postElement, listId) 
{
  var commentInput = prompt('Add a comment:');
  if (commentInput !== null) 
  {
    var index = Array.from(postElement.parentNode.children).indexOf(postElement);
    var commentNumber = maintenanceRequestsMessages[index].comments ? maintenanceRequestsMessages[index].comments.length + 1 : 1;
    maintenanceRequestsMessages[index].comments = maintenanceRequestsMessages[index].comments || [];
    maintenanceRequestsMessages[index].comments.push(commentInput);
    updateMessageList(listId, maintenanceRequestsMessages);
  }
}

function removePost(postElement, listId) 
{
  var index = Array.from(postElement.parentNode.children).indexOf(postElement);
  maintenanceRequestsMessages.splice(index, 1);
  updateMessageList(listId, maintenanceRequestsMessages);
}

function updateClock() 
{
  var now = new Date();
  var hours = now.getHours().toString().padStart(2, '0');
  var minutes = now.getMinutes().toString().padStart(2, '0');
  var seconds = now.getSeconds().toString().padStart(2, '0');
  var currentDate = now.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' });
  document.getElementById('clock').innerHTML = 'Current Date: ' + currentDate + ' ' + hours + ':' + minutes + ':' + seconds;
}

function updateCountdown() 
{
  var maintenanceDate = new Date('December 25, 2023 00:00:00 GMT+0000');
  var now = new Date();
  var timeDifference = maintenanceDate - now;

  var seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);
  var minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
  var hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
  var currentDate = now.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' });
  document.getElementById('countdown').innerHTML =
    'Maintenance Team Available In: ' + 
    days + 'd ' + hours + 'h ' + minutes + 'm ' + seconds + 's';
}
updateClock();
updateCountdown();
setInterval(function () {
  updateClock();
  updateCountdown();
}, 1000);
