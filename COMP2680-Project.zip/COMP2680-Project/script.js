document.addEventListener('DOMContentLoaded', function() 
{
  var ModifiedDate = document.lastModified;
  var UpdatedElement = document.getElementById('last-updated');
  UpdatedElement.textContent = 'Last Updated: ' + ModifiedDate;
});


